```rust
//! Плагиновая система для управления GPL-сервисами.

pub mod loader;

pub use loader::GplPluginLoader;
```